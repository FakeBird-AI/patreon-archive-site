// Worker.js
export default {
  async fetch(request, env) {
    // ───── 環境変数から読み込むシークレット ─────
    const CLIENT_ID     = env.DISCORD_CLIENT_ID;
    const CLIENT_SECRET = env.DISCORD_CLIENT_SECRET;
    const BOT_TOKEN     = env.DISCORD_BOT_TOKEN;
    const GUILD_ID      = env.DISCORD_GUILD_ID;
    const SITE_URL      = env.SITE_URL;
    const SESSION_SECRET= env.SESSION_SECRET;

    // ───── ハードコーディングするロールID ─────
    const ALLOWED_ROLE_IDS = [
      "1350114869780680734", // Premium
      "1350114736242557010", // Special
      "1350114379391045692", // Standard
      "1350114997040316458"  // Owner
    ];

    const CORS_HEADERS = {
      "Access-Control-Allow-Origin": SITE_URL,
      "Access-Control-Allow-Credentials": "true"
    };

    try {
      const url  = new URL(request.url);
      const path = url.pathname;
      const method = request.method;

      // OPTIONS (CORS preflight)
      if (method === "OPTIONS") {
        return new Response(null, {
          status: 204,
          headers: {
            ...CORS_HEADERS,
            "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
            "Access-Control-Allow-Headers": "Content-Type, Authorization"
          }
        });
      }

      // トラッキング
      if (path === "/track" && method === "GET") {
        const auth    = request.headers.get("Authorization") || "";
        const token   = auth.startsWith("Bearer ") ? auth.slice(7) : null;
        const payload = token ? await verifySessionToken(token) : null;
        const userId  = payload?.sub || "anonymous";
        const key     = `visit#${userId}`;
        const prev    = Number(await env.VISITS_KV.get(key) || 0);
        await env.VISITS_KV.put(key, String(prev + 1));
        return new Response("OK", { status: 200, headers: CORS_HEADERS });
      }

      // 管理者アクセス統計
      if (path === "/admin/visits" && method === "GET") {
        const auth    = request.headers.get("Authorization") || "";
        const token   = auth.startsWith("Bearer ") ? auth.slice(7) : null;
        const payload = token ? await verifySessionToken(token) : null;
        if (!payload?.roles?.includes(ALLOWED_ROLE_IDS[3])) {
          return new Response("Forbidden", { status: 403, headers: CORS_HEADERS });
        }
        let cursor;
        const list = [];
        do {
          const page = await env.VISITS_KV.list({ cursor, limit: 100 });
          cursor     = page.cursor;
          for (const k of page.keys) {
            const user  = k.name.replace("visit#", "");
            const count = Number(await env.VISITS_KV.get(k.name));
            list.push({ user, count });
          }
        } while (cursor);
        return new Response(JSON.stringify(list), {
          status: 200,
          headers: { ...CORS_HEADERS, "Content-Type": "application/json" }
        });
      }

      // データ取得
      if (path === "/data.json" && method === "GET") {
        const stored = await env.DATA_KV.get("data.json");
        if (stored) {
          return new Response(stored, {
            status: 200,
            headers: { ...CORS_HEADERS, "Content-Type": "application/json" }
          });
        }
        return new Response("[]", {
          status: 200,
          headers: { ...CORS_HEADERS, "Content-Type": "application/json" }
        });
      }

      // データ更新
      if (path === "/api/update-data" && method === "POST") {
        try {
          const newData = await request.json();
          await env.DATA_KV.put("data.json", JSON.stringify(newData));
          return new Response(JSON.stringify({ success: true }), {
            status: 200,
            headers: { ...CORS_HEADERS, "Content-Type": "application/json" }
          });
        } catch (err) {
          return new Response(JSON.stringify({ success: false, error: err.message }), {
            status: 500,
            headers: { ...CORS_HEADERS, "Content-Type": "application/json" }
          });
        }
      }

      // OAuth: /login
      if (path === "/login") {
        const state = crypto.getRandomValues(new Uint8Array(16))
          .reduce((s, b) => s + b.toString(16).padStart(2, "0"), "");
        const headers = {
          ...CORS_HEADERS,
          "Set-Cookie": `oauth_state=${state}; Secure; HttpOnly; Path=/; Max-Age=300; SameSite=Lax`
        };
        const discordAuthURL =
          `https://discord.com/api/oauth2/authorize?client_id=${CLIENT_ID}` +
          `&redirect_uri=${encodeURIComponent(SITE_URL + "/callback")}` +
          `&response_type=code&scope=identify&state=${state}`;
        return new Response(null, { status: 302, headers: { ...headers, Location: discordAuthURL } });
      }

      // OAuth callback
      if (path === "/callback") {
        const code  = url.searchParams.get("code");
        const state = url.searchParams.get("state");
        if (!code || !state) {
          return new Response("Invalid OAuth callback", { status: 400, headers: CORS_HEADERS });
        }
        const ck = request.headers.get("Cookie") || "";
        const m  = ck.match(/oauth_state=([^;]+)/);
        if (!m || m[1] !== state) {
          return new Response("Invalid state", { status: 400, headers: CORS_HEADERS });
        }
        // token exchange
        const tokenRes = await fetch("https://discord.com/api/oauth2/token", {
          method: "POST",
          headers: { "Content-Type": "application/x-www-form-urlencoded" },
          body: new URLSearchParams({
            client_id:     CLIENT_ID,
            client_secret: CLIENT_SECRET,
            grant_type:    "authorization_code",
            code,
            redirect_uri:  SITE_URL + "/callback"
          })
        });
        if (!tokenRes.ok) {
          return new Response("Token error", { status: 500, headers: CORS_HEADERS });
        }
        const { access_token } = await tokenRes.json();
        // user info
        const userRes = await fetch("https://discord.com/api/v10/users/@me", {
          headers: { Authorization: `Bearer ${access_token}` }
        });
        if (!userRes.ok) {
          return new Response("User fetch error", { status: 500, headers: CORS_HEADERS });
        }
        const user = await userRes.json();
        // guild membership
        const memberRes = await fetch(
          `https://discord.com/api/v10/guilds/${GUILD_ID}/members/${user.id}`,
          { headers: { Authorization: `Bot ${BOT_TOKEN}` } }
        );
        if (!memberRes.ok) {
          return new Response(null, { status: 302, headers: { ...CORS_HEADERS, Location: SITE_URL + "/?error=unauthorized" } });
        }
        const member = await memberRes.json();
        const userRoles = member.roles || [];
        if (!userRoles.some(r => ALLOWED_ROLE_IDS.includes(r))) {
          return new Response(null, { status: 302, headers: { ...CORS_HEADERS, Location: SITE_URL + "/?error=unauthorized" } });
        }
        // 成功 → セッション発行
        const sessionToken = await createSessionToken(user, userRoles, SESSION_SECRET);
        return new Response(null, {
          status: 302,
          headers: { ...CORS_HEADERS, Location: `${SITE_URL}/#token=${sessionToken}` }
        });
      }

      // verify
      if (path === "/verify") {
        let token = null;
        const authHeader = request.headers.get("Authorization");
        if (authHeader?.startsWith("Bearer ")) {
          token = authHeader.slice(7);
        } else {
          const ck = request.headers.get("Cookie") || "";
          const m  = ck.match(/session=([^;]+)/);
          if (m) token = m[1];
        }
        const result = { loggedIn: false };
        if (token) {
          const payload = await verifySessionToken(token, SESSION_SECRET);
          if (payload) {
            result.loggedIn = true;
            result.username = payload.username;
            result.roles    = payload.roles;
          }
        }
        return new Response(JSON.stringify(result), {
          status: 200,
          headers: { ...CORS_HEADERS, "Content-Type": "application/json", "Cache-Control": "no-store" }
        });
      }

      // logout
      if (path === "/logout") {
        return new Response(null, {
          status: 302,
          headers: { ...CORS_HEADERS, Location: SITE_URL + "/?logout=true" }
        });
      }

      // ルートは静的ファイルを返す
      return env.ASSETS.fetch(request);

    } catch (err) {
      console.error("fetch error:", err);
      return new Response("Internal Server Error", { status: 500, headers: CORS_HEADERS });
    }
  }
};

// JWT 発行／検証
async function createSessionToken(user, userRoles, secret) {
  const header  = { alg: "HS256", typ: "JWT" };
  const payload = {
    sub: user.id,
    username: `${user.username}#${user.discriminator || "0000"}`,
    roles: userRoles,
    exp: Math.floor(Date.now() / 1000) + 3600
  };
  const b64 = obj => btoa(String.fromCharCode(...new TextEncoder().encode(JSON.stringify(obj))))
                      .replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
  const h = b64(header), p = b64(payload), data = `${h}.${p}`;
  const key = await crypto.subtle.importKey("raw", new TextEncoder().encode(secret),
    { name: "HMAC", hash: "SHA-256" }, false, ["sign"]);
  const sigBuf = await crypto.subtle.sign("HMAC", key, new TextEncoder().encode(data));
  let bin = ""; new Uint8Array(sigBuf).forEach(b => bin += String.fromCharCode(b));
  const s = btoa(bin).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
  return `${data}.${s}`;
}

async function verifySessionToken(token, secret) {
  const parts = token.split(".");
  if (parts.length !== 3) return null;
  const [h, p, s] = parts;
  try {
    const key = await crypto.subtle.importKey("raw", new TextEncoder().encode(secret),
      { name: "HMAC", hash: "SHA-256" }, false, ["sign"]);
    const data = `${h}.${p}`;
    const buf  = await crypto.subtle.sign("HMAC", key, new TextEncoder().encode(data));
    let bin = ""; new Uint8Array(buf).forEach(b => bin += String.fromCharCode(b));
    const expected = btoa(bin).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
    if (expected !== s) return null;
    const pl = JSON.parse(atob(p.replace(/-/g, "+").replace(/_/g, "/")));
    if (pl.exp && Math.floor(Date.now() / 1000) > pl.exp) return null;
    return pl;
  } catch {
    return null;
  }
}
