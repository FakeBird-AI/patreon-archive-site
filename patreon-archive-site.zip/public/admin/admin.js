// admin.js

const OWNER_ROLE = "1350114997040316458";  // Owner ロールID

document.addEventListener("DOMContentLoaded", async () => {
  // Cookie 取得
  const session = document.cookie.match(/session=([^;]+)/)?.[1];
  if (!session) return location.href = "/";

  // 認証チェック
  let me;
  try {
    const v = await fetch("/verify", {
      credentials: "include",
      headers: { "Authorization": `Bearer ${session}` }
    });
    me = await v.json();
    if (!me.loggedIn || !(me.roles || []).includes(OWNER_ROLE)) {
      document.body.innerHTML = "<p>認証チェックに失敗しました。</p>";
      return;
    }
  } catch {
    document.body.innerHTML = "<p>認証チェックに失敗しました。</p>";
    return;
  }

  // ホーム戻るボタン
  document.getElementById("goHome").addEventListener("click", () => {
    window.location.href = "/";
  });

  // ── 訪問者統計を取得 ──
  try {
    const resp = await fetch("/admin/visits", {
      credentials: "include",
      headers: { "Authorization": `Bearer ${session}` }
    });
    const list = await resp.json(); // [{ user, count }, ...]
    const total = list.reduce((sum, e) => sum + e.count, 0);
    document.getElementById("visitorTotal").textContent = total;
  } catch (e) {
    console.error("訪問者統計取得失敗", e);
  }

  // ── 既存エントリー一覧をロード ──
  const entriesDiv = document.getElementById("entries");
  let data = [];
  try {
    const d = await fetch("/data.json", { credentials: "include" });
    data = await d.json();
  } catch (e) {
    entriesDiv.innerHTML = "<p>エントリー一覧の取得に失敗しました。</p>";
    return;
  }

  // カテゴリ→シリーズ→キャラ構造で描画
  const tree = {};
  data.forEach(item => {
    const { type, series, character } = item.category;
    tree[type] ||= {};
    tree[type][series] ||= [];
    tree[type][series].push(item);
  });

  // 描画
  Object.entries(tree).forEach(([type, seriesMap]) => {
    const typeBtn = document.createElement("button");
    typeBtn.textContent = `▶ ${type}`;
    typeBtn.classList.add("toggle-btn");
    const seriesContainer = document.createElement("div");
    seriesContainer.classList.add("nested");
    Object.entries(seriesMap).forEach(([series, items]) => {
      const seriesBtn = document.createElement("button");
      seriesBtn.textContent = `▶ ${series}`;
      seriesBtn.classList.add("toggle-btn");
      const charContainer = document.createElement("div");
      charContainer.classList.add("nested");
      items.forEach(item => {
        const div = document.createElement("div");
        div.textContent = `${item.date} — ${item.title}`;
        // 編集／削除ボタン
        const edit = document.createElement("button");
        edit.textContent = "✏️";
        edit.onclick = () => populateForm(item);
        const del = document.createElement("button");
        del.textContent = "🗑";
        del.onclick = () => deleteEntry(item.date);
        div.append(edit, del);
        charContainer.append(div);
      });
      seriesContainer.append(seriesBtn, charContainer);
      seriesBtn.addEventListener("click", () => charContainer.classList.toggle("open"));
    });
    entriesDiv.append(typeBtn, seriesContainer);
    typeBtn.addEventListener("click", () => seriesContainer.classList.toggle("open"));
  });

  // ── フォーム操作 ──
  const form = document.getElementById("archiveForm");
  const msgP = document.getElementById("formMessage");
  form.addEventListener("submit", async e => {
    e.preventDefault();
    // フォームからオブジェクト生成
    const entry = {
      date:    document.getElementById("date").value,
      title:   document.getElementById("title").value,
      thumbnail: document.getElementById("thumbnail").value,
      category: {
        type:      document.getElementById("type").value,
        series:    document.getElementById("series").value,
        character: document.getElementById("character").value
      },
      tags: document.getElementById("tags").value.split(",").map(t => t.trim()).filter(t => t),
      patreonUrl: document.getElementById("patreonUrl").value,
      boothUrl:   document.getElementById("boothUrl").value,
      url:        document.getElementById("url").value
    };
    // 既存データを取得して更新
    let all = [];
    try {
      all = await (await fetch("/data.json", { credentials: "include" })).json();
      // 同一 date があれば置き換え
      const idx = all.findIndex(o => o.date === entry.date);
      if (idx >= 0) all[idx] = entry;
      else all.push(entry);
      const upd = await fetch("/api/update-data", {
        method: "POST",
        credentials: "include",
        headers: {
          "Content-Type": "application/json",
          "Authorization": `Bearer ${session}`
        },
        body: JSON.stringify(all)
      });
      const res = await upd.json();
      msgP.textContent = res.success ? "保存しました！" : `エラー: ${res.error}`;
      setTimeout(() => location.reload(), 500);
    } catch (err) {
      msgP.textContent = `保存に失敗しました: ${err}`;
    }
  });

  document.getElementById("clearForm").addEventListener("click", () => form.reset());
},

// フォームに既存値を埋める
function populateForm(item) {
  document.getElementById("date").value      = item.date;
  document.getElementById("title").value     = item.title;
  document.getElementById("thumbnail").value = item.thumbnail;
  document.getElementById("type").value      = item.category.type;
  document.getElementById("series").value    = item.category.series;
  document.getElementById("character").value = item.category.character;
  document.getElementById("tags").value      = item.tags.join(",");
  document.getElementById("patreonUrl").value = item.patreonUrl || "";
  document.getElementById("boothUrl").value   = item.boothUrl || "";
  document.getElementById("url").value        = item.url;
},

// 削除
async function deleteEntry(date) {
  if (!confirm("本当に削除しますか？")) return;
  let all = await (await fetch("/data.json", { credentials: "include" })).json();
  all = all.filter(o => o.date !== date);
  await fetch("/api/update-data", {
    method: "POST",
    credentials: "include",
    headers: {
      "Content-Type": "application/json",
      "Authorization": `Bearer ${document.cookie.match(/session=([^;]+)/)[1]}`
    },
    body: JSON.stringify(all)
  });
  location.reload();
})
