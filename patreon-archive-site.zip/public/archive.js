// archive.js
const API_ORIGIN = "https://patreon-archive-site.fakebird279.workers.dev";
let selectedCharacter = null;

function parseDate(dateStr) {
  const y = +dateStr.slice(0, 4);
  const m = +dateStr.slice(4, 6) - 1;
  const d = +dateStr.slice(6, 8);
  return new Date(y, m, d);
}

function getZipLinkContent(item) {
  const PRIORITY = {
    "1350114997040316458": 4,
    "1350114869780680734": 3,
    "1350114736242557010": 2,
    "1350114379391045692": 1
  };
  let max = 0, role = null;
  (window.userRoles || []).forEach(r => {
    if ((PRIORITY[r] || 0) > max) {
      max = PRIORITY[r]; role = r;
    }
  });
  const fileDate = parseDate(item.date);
  const oneMonthAgo = new Date();
  oneMonthAgo.setMonth(oneMonthAgo.getMonth() - 1);
  const recent = fileDate >= oneMonthAgo;
  switch (role) {
    case "1350114997040316458":
    case "1350114869780680734":
      return `<a href="${item.url}" class="link">▶ ZIPリンク</a>`;
    case "1350114736242557010":
      return recent
        ? `<a href="${item.url}" class="link">▶ ZIPリンク</a>`
        : "1ヶ月より前のアーカイブです。Premiumにアップグレードすると閲覧可能です。";
    default:
      return "このコンテンツにアクセスできません。";
  }
}

function appendAdminLink() {
  if ((window.userRoles || []).includes("1350114997040316458")) {
    const container = document.querySelector('#mobile-menu .p-4');
    if (!container) return;
    const wrapper = document.createElement('div');
    wrapper.style.marginTop = '2rem';
    wrapper.style.textAlign = 'center';
    const a = document.createElement('a');
    a.href = '/admin/';
    a.className = 'admin-link';
    a.textContent = '管理者ページへ';
    wrapper.appendChild(a);
    container.appendChild(wrapper);
  }
}

// ログアウトリンクをサイドバー下部へ移動
function appendLogout() {
  const logoutBtn = document.getElementById('logout-btn');
  const container = document.querySelector('#mobile-menu .p-4');
  if (logoutBtn && container) {
    // 親から切り離してサイドバーに追加
    logoutBtn.remove();
    container.appendChild(logoutBtn);
  }
}

async function initArchive() {
  console.log("✅ initArchive() start");
  const archiveDiv = document.getElementById("archive");
  const tagList = document.getElementById("tag-list");
  const searchBox = document.getElementById("search-box");
  if (!archiveDiv || !tagList || !searchBox) return;
  tagList.classList.remove("open");
  let data = [];
  try {
    const res = await fetch(`${API_ORIGIN}/data.json`, { credentials: "include" });
    data = await res.json();
  } catch (e) {
    archiveDiv.innerHTML = "<p>アーカイブの読み込みに失敗しました。</p>";
    return;
  }
  if (!Array.isArray(data) || data.length === 0) {
    archiveDiv.innerHTML = "<p>アーカイブがありません。</p>";
    return;
  }
  data.sort((a, b) => b.date.localeCompare(a.date));
  const tree = {};
  data.forEach(item => {
    const { type, series, character } = item.category;
    tree[type] ||= {};
    tree[type][series] ||= [];
    if (!tree[type][series].includes(character)) tree[type][series].push(character);
  });
  Object.entries(tree).forEach(([type, seriesMap]) => {
    const typeBtn = document.createElement("button");
    typeBtn.textContent = `▶ ${type}`;
    typeBtn.className = "toggle";
    const seriesUl = document.createElement("ul"); seriesUl.className = "series-list";
    typeBtn.addEventListener("click", () => {
      seriesUl.classList.toggle("open");
      typeBtn.textContent = seriesUl.classList.contains("open") ? `▼ ${type}` : `▶ ${type}`;
    });
    const typeLi = document.createElement("li"); typeLi.append(typeBtn, seriesUl); tagList.appendChild(typeLi);
    Object.entries(seriesMap).forEach(([series, chars]) => {
      const seriesBtn = document.createElement("button");
      seriesBtn.textContent = `▶ ${series}`; seriesBtn.className = "toggle";
      const charUl = document.createElement("ul"); charUl.className = "character-list";
      seriesBtn.addEventListener("click", () => {
        charUl.classList.toggle("open");
        seriesBtn.textContent = charUl.classList.contains("open") ? `▼ ${series}` : `▶ ${series}`;
      });
      const seriesLi = document.createElement("li"); seriesLi.append(seriesBtn, charUl); seriesUl.appendChild(seriesLi);
      chars.forEach(character => {
        const charBtn = document.createElement("button"); charBtn.textContent = character;
        charBtn.addEventListener("click", () => { selectedCharacter = character; render(); });
        const charLi = document.createElement("li"); charLi.appendChild(charBtn); charUl.appendChild(charLi);
      });
    });
  });
  function render() {
    archiveDiv.innerHTML = "";
    const kw = searchBox.value.trim().toLowerCase();
    const filtered = data.filter(item => {
      return (!selectedCharacter || item.category.character === selectedCharacter) && (!kw ||
        item.title.toLowerCase().includes(kw) || item.category.series.toLowerCase().includes(kw) ||
        item.category.character.toLowerCase().includes(kw) || item.tags.some(t => t.toLowerCase().includes(kw)));
    });
    if (filtered.length === 0) { archiveDiv.innerHTML = "<p>該当する作品が見つかりませんでした。</p>"; return; }
    filtered.forEach(item => {
      const card = document.createElement("div"); card.className = "card";
      card.innerHTML = `
        <img src="${item.thumbnail}" alt="${item.title}">
        <h3>${item.title}</h3>
        <p>${item.date}</p>
        ${item.boothUrl ? `<a href="${item.boothUrl}" class="link">▶ BOOTHリンク</a>` : ""}
        ${item.patreonUrl ? `<a href="${item.patreonUrl}" class="link">▶ Patreonリンク</a>` : ""}
        ${getZipLinkContent(item)}
      `;
      archiveDiv.appendChild(card);
    });
  }
  render(); searchBox.addEventListener("input", render);
  appendAdminLink(); appendLogout();
}
window.initArchive = initArchive;